"use client";

import { useEffect } from "react";
import { useSearchStore } from "@/store/search-store";
import { HomeScreen } from "@/components/search-engine/home-screen";
import { ResultsView } from "@/components/search-engine/results-view";
import { ProxyView } from "@/components/search-engine/proxy-view";
import { SiteFooter } from "@/components/search-engine/footer";
import {
  Sidebar,
  MobileBottomBar,
} from "@/components/shabah/sidebar";
import { AiPanel } from "@/components/shabah/ai-panel";
import { SettingsView } from "@/components/shabah/settings-view";
import { AdminDashboard } from "@/components/shabah/admin-dashboard";

export default function Home() {
  const view = useSearchStore((s) => s.view);
  const setView = useSearchStore((s) => s.setView);

  // Scroll to top when view changes
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  }, [view]);

  // Global listener: any "submit" event switches to results view.
  useEffect(() => {
    const handler = () => setView("results");
    window.addEventListener("onionsearch:submit", handler);
    return () => window.removeEventListener("onionsearch:submit", handler);
  }, [setView]);

  return (
    <div className="min-h-screen flex bg-background text-foreground">
      {/* Sidebar (desktop only) */}
      <Sidebar />

      {/* Main content area (fills the rest, sidebar on right because RTL) */}
      <div className="flex-1 flex flex-col min-w-0">
        <div className="flex-1 flex flex-col pb-14 sm:pb-0">
          {view === "home" && <HomeScreen />}
          {view === "results" && <ResultsView />}
          {view === "proxy" && <ProxyView />}
          {view === "settings" && <SettingsView />}
          {view === "admin" && <AdminDashboard />}
        </div>
        <SiteFooter />
      </div>

      {/* AI slide-in panel (always available) */}
      <AiPanel />

      {/* Mobile bottom navigation */}
      <MobileBottomBar />
    </div>
  );
}

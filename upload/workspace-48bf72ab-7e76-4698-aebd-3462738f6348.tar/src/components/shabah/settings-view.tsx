"use client";

import { useState } from "react";
import {
  Settings2,
  Globe,
  ShieldCheck,
  EyeOff,
  Search,
  Flame,
  Info,
  RotateCcw,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Slider } from "@/components/ui/slider";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useSettingsStore, SECURITY_LEVELS } from "@/store/settings-store";
import { usePrivacyStore } from "@/store/privacy-store";
import { SecuritySlider } from "./security-slider";
import { SessionIdBadge } from "./session-id";
import { ShabahLogo } from "./logo";
import { COUNTRIES } from "./countries";

const SECTIONS = [
  { key: "general", label: "عام", icon: Settings2 },
  { key: "circuit", label: "الدائرة", icon: Globe },
  { key: "security", label: "الأمان", icon: ShieldCheck },
  { key: "privacy", label: "الخصوصية", icon: EyeOff },
  { key: "search", label: "البحث", icon: Search },
  { key: "firewall", label: "الجدار الناري", icon: Flame },
  { key: "about", label: "حول", icon: Info },
] as const;

export function SettingsView() {
  const [section, setSection] = useState<string>("general");
  const s = useSettingsStore();
  const { rotateCircuit, newIdentity } = usePrivacyStore();

  return (
    <main className="flex-1 w-full">
      {/* Header */}
      <div className="border-b border-border bg-background/80 backdrop-blur sticky top-0 z-10">
        <div className="max-w-4xl mx-auto px-4 py-4 flex items-center gap-3">
          <div className="w-10 h-10 relative">
            <ShabahLogo size={40} />
          </div>
          <div>
            <h1 className="text-xl font-bold">الإعدادات</h1>
            <p className="text-xs text-muted-foreground">
              خصّص متصفّحك المجهّل — كل التفضيلات محفوظة محليًا فقط
            </p>
          </div>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 py-6">
        <Tabs value={section} onValueChange={setSection} className="flex flex-col md:flex-row gap-6">
          <TabsList
            orientation="vertical"
            className="flex md:flex-col h-auto md:w-48 shrink-0 bg-card/40 border border-border p-1"
          >
            {SECTIONS.map((sec) => {
              const Icon = sec.icon;
              return (
                <TabsTrigger
                  key={sec.key}
                  value={sec.key}
                  className="justify-start gap-2 w-full data-[state=active]:bg-primary/15 data-[state=active]:text-primary"
                >
                  <Icon className="w-4 h-4" />
                  <span className="hidden sm:inline">{sec.label}</span>
                </TabsTrigger>
              );
            })}
          </TabsList>

          <div className="flex-1 min-w-0 space-y-6">
            {/* GENERAL */}
            <TabsContent value="general" className="mt-0 space-y-4">
              <Section title="عام" desc="إعدادات أساسية للمتصفّح">
                <Row label="السمة" desc="داكن أو فاتح">
                  <Select value={s.theme} onValueChange={(v) => s.set("theme", v as any)}>
                    <SelectTrigger className="w-32"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="dark">داكن</SelectItem>
                      <SelectItem value="light">فاتح</SelectItem>
                    </SelectContent>
                  </Select>
                </Row>
                <Row label="اللغة" desc="لغة الواجهة">
                  <Select value={s.language} onValueChange={(v) => s.set("language", v as any)}>
                    <SelectTrigger className="w-32"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="ar">العربية</SelectItem>
                      <SelectItem value="en">English</SelectItem>
                    </SelectContent>
                  </Select>
                </Row>
                <Row label="عدد النتائج لكل صفحة" desc={`${s.resultsPerPage} نتيجة`}>
                  <div className="w-40">
                    <Slider
                      value={[s.resultsPerPage]}
                      onValueChange={(v) => s.set("resultsPerPage", v[0])}
                      min={6}
                      max={20}
                      step={2}
                    />
                  </div>
                </Row>
                <Row label="التبويب الافتراضي" desc="أي تبويب يُفتح عند البحث">
                  <Select value={s.defaultTab} onValueChange={(v) => s.set("defaultTab", v as any)}>
                    <SelectTrigger className="w-32"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="web">ويب</SelectItem>
                      <SelectItem value="news">أخبار</SelectItem>
                      <SelectItem value="images">صور</SelectItem>
                    </SelectContent>
                  </Select>
                </Row>
                <Row label="وضع المدير" desc="إظهار تبويب لوحة التحكم في الشريط الجانبي">
                  <Switch checked={s.adminMode} onCheckedChange={(v) => s.set("adminMode", v)} />
                </Row>
              </Section>
            </TabsContent>

            {/* CIRCUIT */}
            <TabsContent value="circuit" className="mt-0 space-y-4">
              <Section title="دائرة التوجيه" desc="تحكّم في عُقد التوجيه (Tor-like multi-hop)">
                <div className="rounded-lg border border-border bg-background/40 p-3">
                  <div className="text-xs text-muted-foreground mb-2">عقد التوجيه الحالية:</div>
                  <CircuitPreview />
                </div>
                <Row label="دولة حارس الدخول" desc="أول عقدة ترى اتصالك">
                  <Select value={s.entryCountry} onValueChange={(v) => s.set("entryCountry", v)}>
                    <SelectTrigger className="w-40"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="auto">تلقائي (موصى به)</SelectItem>
                      {COUNTRIES.map((c) => (
                        <SelectItem key={c.code} value={c.code}>{c.flag} {c.name}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </Row>
                <Row label="دولة عقدة الخروج" desc="آخر عقدة — هي ما يظهر للموقع">
                  <Select value={s.exitCountry} onValueChange={(v) => s.set("exitCountry", v)}>
                    <SelectTrigger className="w-40"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="auto">تلقائي (موصى به)</SelectItem>
                      {COUNTRIES.map((c) => (
                        <SelectItem key={c.code} value={c.code}>{c.flag} {c.name}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </Row>
                <Row label="دوران تلقائي" desc={`تبديل الدائرة كل ${s.rotateEveryMinutes} دقيقة`}>
                  <div className="w-40">
                    <Slider
                      value={[s.rotateEveryMinutes]}
                      onValueChange={(v) => s.set("rotateEveryMinutes", v[0])}
                      min={5}
                      max={60}
                      step={5}
                    />
                  </div>
                </Row>
                <Row label="منع WebRTC" desc="يمنع تسريب IP الحقيقي عبر WebRTC">
                  <Switch checked={s.blockWebRTC} onCheckedChange={(v) => s.set("blockWebRTC", v)} />
                </Row>
                <Row label="مفتاح الإيقاف (Kill Switch)" desc="يقطع الاتصال عند تعطّل الـ VPN">
                  <Switch checked={s.killSwitch} onCheckedChange={(v) => s.set("killSwitch", v)} />
                </Row>
                <div className="flex gap-2 pt-2">
                  <Button onClick={rotateCircuit} variant="outline" size="sm">
                    <RotateCcw className="w-3.5 h-3.5 ml-1.5" />
                    دورة جديدة فورية
                  </Button>
                  <Button onClick={newIdentity} variant="outline" size="sm">
                    <RotateCcw className="w-3.5 h-3.5 ml-1.5" />
                    هوية جديدة
                  </Button>
                </div>
              </Section>
            </TabsContent>

            {/* SECURITY */}
            <TabsContent value="security" className="mt-0 space-y-4">
              <Section title="مستوى الأمان" desc="نمط Tor ثلاثي المستويات — يحدد ما يُسمح به أثناء التصفّح">
                <SecuritySlider />
                <div className="rounded-lg border border-primary/20 bg-primary/5 p-3 text-xs leading-relaxed">
                  <span className="text-primary font-semibold">ماذا يعني ذلك؟</span>{" "}
                  في المستوى الأقصى، السكربتات والصور والخطوط الخارجية معطّلة،
                  وبصمة الجهاز مموّهة بالكامل. هذا يبطّئ بعض المواقع لكنه يحميك أقصى حماية.
                </div>
              </Section>
            </TabsContent>

            {/* PRIVACY */}
            <TabsContent value="privacy" className="mt-0 space-y-4">
              <Section title="الخصوصية" desc="تحكّم في ما يُحفظ أو يُحظر">
                <Row label="عدم حفظ السجل" desc="لا نتائج بحث، لا تاريخ تصفّح، لا كوكيز بعد إغلاق الجلسة">
                  <Switch checked={s.noHistory} onCheckedChange={(v) => s.set("noHistory", v)} />
                </Row>
                <Row label="إزالة المتتبّعات" desc="حظر سكربتات التتبّع (Google Analytics, Facebook Pixel...)">
                  <Switch checked={s.stripTrackers} onCheckedChange={(v) => s.set("stripTrackers", v)} />
                </Row>
                <Row label="حظر الإعلانات" desc="حظر شبكات الإعلانات والنوافذ المنبثقة">
                  <Switch checked={s.blockAds} onCheckedChange={(v) => s.set("blockAds", v)} />
                </Row>
                <Row label="كوكيز الطرف الثالث" desc="حظر ملفات تعريف الارتباط من نطاقات خارجية">
                  <Switch checked={s.blockThirdPartyCookies} onCheckedChange={(v) => s.set("blockThirdPartyCookies", v)} />
                </Row>
                <Row label="تمويه البصمة" desc="تغيير User-Agent و Canvas WebGL لمنع التعرف">
                  <Switch checked={s.spoofFingerprint} onCheckedChange={(v) => s.set("spoofFingerprint", v)} />
                </Row>
                <Row label="منع فحص المنافذ" desc="حظر موجات مسح المنافذ و محاولات الاختراق">
                  <Switch checked={s.doshBlock} onCheckedChange={(v) => s.set("doshBlock", v)} />
                </Row>
                <Row label="فتح الروابط عبر البروكسي دائمًا" desc="كل رابط تضغط عليه يُفتح عبر شبح مجهّل">
                  <Switch checked={s.openLinksViaProxy} onCheckedChange={(v) => s.set("openLinksViaProxy", v)} />
                </Row>
              </Section>
            </TabsContent>

            {/* SEARCH */}
            <TabsContent value="search" className="mt-0 space-y-4">
              <Section title="البحث" desc="سلوك محرك البحث">
                <Row label="موجز شبح AI" desc="إظهار إجابة موجزة من الذكاء الاصطناعي فوق النتائج">
                  <Switch checked={s.aiSummarizer} onCheckedChange={(v) => s.set("aiSummarizer", v)} />
                </Row>
                <Row label="اختصارات !بانغ" desc="مثال: !ويكي البرتقال → ويكيبيديا">
                  <Switch checked={s.bangsEnabled} onCheckedChange={(v) => s.set("bangsEnabled", v)} />
                </Row>
                <Row label="الإجابات الفورية" desc="عرض بطاقات معلومات عند تطابق الاستعلام">
                  <Switch checked={s.instantAnswers} onCheckedChange={(v) => s.set("instantAnswers", v)} />
                </Row>
                <Row label="البحث الآمن" desc="فلترة المحتوى الإباحي">
                  <Switch checked={s.safeSearch} onCheckedChange={(v) => s.set("safeSearch", v)} />
                </Row>
              </Section>
            </TabsContent>

            {/* FIREWALL */}
            <TabsContent value="firewall" className="mt-0 space-y-4">
              <Section title="جدار شبح الناري" desc="حماية نشطة من موجات الاختراق">
                <Row label="تفعيل الجدار الناري" desc="حركة مرور نشطة مع حظر تلقائي">
                  <Switch checked={s.firewallEnabled} onCheckedChange={(v) => s.set("firewallEnabled", v)} />
                </Row>
                <Row label="حظر النطاقات الخبيثة" desc="قائمة سوداء محدّثة من نطاقات التصيّد">
                  <Switch checked={s.blockMaliciousDomains} onCheckedChange={(v) => s.set("blockMaliciousDomains", v)} />
                </Row>
                <Row label="حظر المتتبّعات" desc="حظر اتصالات لمستتعقبي الويب">
                  <Switch checked={s.blockTrackers} onCheckedChange={(v) => s.set("blockTrackers", v)} />
                </Row>
                <Row label="حظر تعدين العملات" desc="منع سكربتات Crypto-Mining التي تستنزف المعالج">
                  <Switch checked={s.blockCryptoMining} onCheckedChange={(v) => s.set("blockCryptoMining", v)} />
                </Row>
                <Row label="حظر بصمة الإصبع" desc="منع تقنيات Fingerprinting (Canvas, Audio, Font)">
                  <Switch checked={s.blockFingerprinting} onCheckedChange={(v) => s.set("blockFingerprinting", v)} />
                </Row>
                <FirewallPreview />
              </Section>
            </TabsContent>

            {/* ABOUT */}
            <TabsContent value="about" className="mt-0 space-y-4">
              <Section title="حول شبح" desc="">
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-16 h-16 relative">
                    <ShabahLogo size={64} float />
                  </div>
                  <div>
                    <div className="text-2xl font-bold">
                      <span className="text-primary">ش</span>بح
                    </div>
                    <div className="text-xs text-muted-foreground font-mono dir-ltr">SHABAH v1.0 · PRIVATE</div>
                  </div>
                </div>
                <p className="text-sm text-muted-foreground leading-relaxed">
                  متصفّح بحث مجهّل يدمج بين بساطة Tor ومميزات Opera. توجيه متعدد
                  العناوين (3 عُقد)، جدار ناري نشط، AI مدمج، صفر بيانات محفوظة.
                </p>
                <div className="grid grid-cols-2 gap-2 mt-4">
                  <SessionIdBadge />
                  <div className="rounded-xl border border-border bg-card/40 p-4">
                    <div className="text-xs text-muted-foreground mb-1">التشفير</div>
                    <div className="text-sm font-mono text-primary">ChaCha20-Poly1305</div>
                    <div className="text-[10px] text-muted-foreground mt-1">+ AES-256-GCM احتياطي</div>
                  </div>
                </div>
                <div className="mt-4 rounded-lg border border-border bg-background/40 p-3 text-xs text-muted-foreground leading-relaxed">
                  <span className="text-foreground font-semibold">التزام الخصوصية:</span>{" "}
                  لا نخزّن أي بيانات. لا سجلّات IP، لا استعلامات بحث، لا كوكيز. كل
                  عمليات البحث تُنفّذ من الخادم نيابةً عنك، والذاكرة تُمحى عند الإغلاق.
                </div>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={s.reset}
                  className="mt-3"
                >
                  <RotateCcw className="w-3.5 h-3.5 ml-1.5" />
                  إعادة ضبط كل الإعدادات
                </Button>
              </Section>
            </TabsContent>
          </div>
        </Tabs>
      </div>
    </main>
  );
}

function Section({ title, desc, children }: { title: string; desc: string; children: React.ReactNode }) {
  return (
    <div className="rounded-xl border border-border bg-card/40 p-4">
      <h2 className="text-base font-semibold">{title}</h2>
      {desc && <p className="text-xs text-muted-foreground mt-0.5 mb-4">{desc}</p>}
      <div className="space-y-1">{children}</div>
    </div>
  );
}

function Row({ label, desc, children }: { label: string; desc: string; children: React.ReactNode }) {
  return (
    <div className="flex items-center justify-between gap-3 py-2.5 border-t border-border/60 first:border-0">
      <div className="min-w-0 flex-1">
        <div className="text-sm font-medium">{label}</div>
        <div className="text-[11px] text-muted-foreground leading-snug">{desc}</div>
      </div>
      <div className="shrink-0">{children}</div>
    </div>
  );
}

function CircuitPreview() {
  const relays = usePrivacyStore((s) => s.relays);
  return (
    <div className="flex items-center gap-2 flex-wrap">
      {relays.map((r, i) => (
        <div key={i} className="flex items-center gap-2">
          <div className="text-center">
            <div className="text-lg">{flagEmoji(r.flag)}</div>
            <div className="text-[9px] text-muted-foreground">{r.label}</div>
            <code className="text-[9px] text-primary dir-ltr">{r.ip}</code>
          </div>
          {i < relays.length - 1 && (
            <div className="text-primary/60 text-xs">←</div>
          )}
        </div>
      ))}
    </div>
  );
}

function FirewallPreview() {
  const blocked = usePrivacyStore((s) => s.blockedAttempts);
  return (
    <div className="mt-3 rounded-lg border border-primary/20 bg-primary/5 p-3">
      <div className="flex items-center justify-between">
        <span className="text-xs text-muted-foreground">محاولات اعتراض اليوم</span>
        <span className="text-2xl font-bold text-primary tabular-nums">{blocked}</span>
      </div>
      <div className="mt-2 grid grid-cols-7 gap-1">
        {Array.from({ length: 21 }).map((_, i) => (
          <div
            key={i}
            className={`h-6 rounded-sm ${
              i < Math.min(21, blocked) ? "bg-primary/60" : "bg-primary/10"
            }`}
          />
        ))}
      </div>
      <div className="text-[10px] text-muted-foreground mt-1.5">
        XSS · CSRF · Port-Scan · Malicious · Tracker · Miner · Fingerprint
      </div>
    </div>
  );
}

function flagEmoji(code: string) {
  if (!code || code.length !== 2) return "🏳";
  const cp = [...code.toUpperCase()].map((c) => 0x1f1e6 + (c.charCodeAt(0) - 65));
  return String.fromCodePoint(...cp);
}

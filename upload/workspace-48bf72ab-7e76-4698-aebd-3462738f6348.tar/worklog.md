# Worklog - Private Search Engine (محرك بحث خاص + VPN/Proxy مجهّل)

## Project Overview
Building a privacy-focused search engine with:
- Web search without restrictions (using web-search skill)
- Anonymous Proxy browsing (using web-reader skill) - fetches page content server-side so user's IP never reaches target site (Tor/VPN-like behavior)
- Tor-inspired dark UI with circuit/relay visualization
- Single-page app on `/` route with view state (home/results/proxy)

## Tech Stack
- Next.js 16 App Router + TypeScript
- Tailwind CSS 4 + shadcn/ui (New York style)
- Zustand for client state, TanStack Query for server state
- z-ai-web-dev-sdk (backend only) for web_search + page_reader functions

## File Plan
- src/app/layout.tsx (dark theme default)
- src/app/globals.css (custom cyber/dark theme tokens)
- src/app/page.tsx (single page, view-state driven)
- src/components/search-engine/* (search-bar, home-screen, results-view, proxy-view, privacy-panel, result-card, tor-circuit, footer)
- src/store/search-store.ts (Zustand)
- src/app/api/search/route.ts (web_search wrapper)
- src/app/api/proxy/route.ts (page_reader wrapper - anonymous proxy)
- src/lib/zai.ts (shared ZAI client)

---
Task ID: 0
Agent: main
Task: Initial planning, skill loading, worklog creation

Work Log:
- Read project structure (Next.js 16, shadcn/ui present, Tailwind 4)
- Invoked web-search skill: returns SearchFunctionResultItem[] with {url,name,snippet,host_name,rank,date,favicon}
- Invoked web-reader skill: returns {data:{title,url,html,publishedTime,usage:{tokens}}}
- Decided single-page app pattern (home -> results -> anonymous proxy view) all on `/`
- Dark Tor-inspired theme with neon-green (lime) accent, avoiding blue/indigo per project rules

Stage Summary:
- Skills loaded and understood
- Architecture decided: SPA with view-state, two API routes (search + proxy), dark Tor-inspired aesthetic
- Next: build frontend then backend

---
Task ID: 1
Agent: main
Task: Build the complete private search engine (frontend + backend + proxy)

Work Log:
- Updated src/app/globals.css: dark Tor-inspired theme (neon lime primary, charcoals), custom scrollbar, glow effects, pulse-ring animation, grid-bg, proxy-content styles
- Updated src/app/layout.tsx: RTL Arabic lang, dark class on html, new metadata
- Replaced public/logo.svg with custom onion mascot (green gradient + sprouts + eyes)
- Created src/lib/zai.ts: shared ZAI SDK client (server-only, reused)
- Created src/store/search-store.ts: Zustand store (view/query/tab/results/proxy/history)
- Created src/store/privacy-store.ts: Zustand store (connected/relays/visibleIp/stats, rotateCircuit)
- Created src/components/search-engine/search-bar.tsx: hero + compact variants, history dropdown, animated focus border
- Created src/components/search-engine/privacy-panel.tsx: 3-hop circuit visualization, stats, encryption badge
- Created src/components/search-engine/home-screen.tsx: onion logo, status pill, search bar, suggestions, features, privacy promise
- Created src/components/search-engine/result-card.tsx: result card + skeleton + favicon handling
- Created src/components/search-engine/results-view.tsx: sticky search bar, tabs (web/news/images), sidebar privacy panel
- Created src/components/search-engine/proxy-view.tsx: anonymous proxy viewer with link-interception (re-proxies absolute links)
- Created src/components/search-engine/footer.tsx: sticky footer with status indicators
- Rewrote src/app/page.tsx: single page with view-state (home/results/proxy), global submit listener
- Created src/app/api/search/route.ts: web_search wrapper with in-memory cache (5min), tab-aware query building
- Created src/app/api/proxy/route.ts: page_reader wrapper with HTML sanitization (strips scripts/iframes/event handlers/tracking pixels), 30min cache

Verification:
- `bun run lint` -> 0 errors, 7 warnings (all unused eslint-disable directives)
- dev server starts cleanly on :3000
- /api/search?q=tor -> returns 3 real results (torproject.org, wikipedia)
- /api/proxy?url=https://example.com -> returns sanitized HTML
- agent-browser: home renders with logo/search/suggestions/features/footer
- agent-browser: search "كيف يعمل tor" -> 8 result cards with anonymous-browse buttons
- agent-browser: clicked "تصفّح مجهّل" -> proxy view loads full Al Jazeera article content with fake exit-IP shown
- mobile (400x800) and desktop (1280x800) both render correctly
- footer is sticky (mt-auto on flex-col wrapper)

Stage Summary:
- Complete privacy-focused search engine built and verified end-to-end
- Web search works (no restrictions - all results returned)
- Anonymous Proxy works: fetches any site's content server-side via web-reader skill, strips scripts/trackers, shows page with fake exit-node IP
- Tor-like circuit visualization (Guard/Middle/Exit, 3 random countries) with rotate button
- Dark RTL Arabic UI with onion mascot, neon-lime accent
- Sticky footer with live connection status

---
Task ID: 2-research
Agent: general-purpose (research)
Task: Research competitor privacy browsers/search engines

Work Log:
- Read worklog.md to understand project state (dark Tor-inspired SPA with web_search + page_reader proxy, 3-hop circuit, onion mascot, RTL Arabic UI already built)
- Ran 9 web_search queries via z-ai CLI on: Tor UI/circuit, Opera Aria/AI/VPN, DDG !bangs/anonymous, Brave Summarizer/independent index, Mullvad multihop/no-account, 2026 privacy comparisons, Tor settings/security levels, Opera GX vs Tor, admin dashboard metrics, DDG Duck.ai, Mullvad Tor partnership
- Fetched & parsed 2 key articles via page_reader: brave.com/blog/ai-summarizer (Summarizer architecture) and support.torproject.org security-levels (3-tier slider Standard/Safer/Safest with feature trade-offs)
- Cross-referenced findings to map patterns onto شبح's existing features (circuit viz, proxy view, footer)

Key Findings per competitor:

### 1. Tor Browser
- **Homepage**: simplified post-13.0 — central search, onionize-DuckDuckGo search toggle, no clutter
- **Per-tab circuit display** (12.5+): opens as panel beside address bar showing Guard → Middle → Exit country flags + "New Circuit for this Site" button (NEW IDENTITY rotates everything; NEW CIRCUIT just rotates path for one site)
- **3-tier Security slider** (Standard / Safer / Safest): each step disables JS, fonts, math symbols, HTML5 media (click-to-play), images — explicit trade-off framing "weigh security needs against usability"
- **No storage**: no cookies/history/queries persist across sessions; first-run always lands on a blank state
- **Settings**: about:preferences-style — General / Home / Search / Privacy & Security / Tor (circuit path, bridges, pluggable transports)
- Admin/dev: relays run by volunteers; no central admin panel — design lesson is *transparency, not controls*

### 2. Opera Browser (Aria / Opera AI)
- **Sidebar AI** (Aria → Opera AI): always-available chat panel; can drag conversation out into its own tab (Opera GX March 2025)
- AI does: page-content summarization, tab management, image generation, file analysis, real-time web answers, translation, sentence-level query refinement
- **Free built-in VPN** (proxy not true VPN), ad blocker, **Flow** file sharing, **Speed Dial** visual bookmarks, integrated news feed
- Settings: granular toggle per feature in sidebar; AI opt-in/opt-out toggle; VPN region picker
- AI integration pattern: keyboard shortcut + sidebar button + in-page context menu — three entry points for the same assistant

### 3. DuckDuckGo
- **!Bangs**: 13,566+ shortcuts (`!w` Wikipedia, `!yt` YouTube…) launched directly from search bar — power-user shortcut layer
- **No IP storage**: GeoIP used transiently for localized results, never persisted
- **Privacy Grade**: letter grade A–F per site showing trackers blocked, encryption, privacy practices — surfaces as a badge in SERP and as browser extension icon
- **App Tracking Protection** (Android): blocks 3rd-party trackers inside other apps, even background
- **Duck.ai**: anonymous multi-model AI chat (Claude 4.5 Haiku, Mistral, GPT) — chats anonymized server-side, NOT used for training, no account required, free
- Settings: "More from DuckDuckGo" section consolidates AI / tracking / browser under one umbrella

### 4. Brave Search
- **Truly independent index** (3rd English-language index after Google/Bing) — independence is the marketing wedge
- **Summarizer AI** (Mar 2023): concise answer block at TOP of SERP, trained LLMs to *aggregate multiple web sources* (not pure generation) → less hallucination; **always cites provenance via links** beside each claim; user can opt-out in settings
- Snippet-level summarization: replaces result descriptions with summarized versions highlighting the answer
- **Shields panel**: per-site AND global settings, accessible from address bar lion icon; Advanced controls expand (block-counts per category); Block Elements (Android 1.78) lets user tap any page element to hide it permanently
- Settings: clear "Independent Index" + "No profiling, no bias, no Big Tech" copy; AI toggle, region/language

### 5. Mullvad VPN / Mullvad Browser
- **Multi-hop**: 2+ servers in different jurisdictions; entry server ≠ exit server country; user picks both
- **Kill switch ALWAYS ON** — by design cannot be disabled; enforced via system firewall integration (WFP on Windows, nftables on Linux, PF on macOS)
- **No-account model**: €5/month flat, no email, no name — just a 16-digit account number shown once at signup
- **Mullvad Browser**: co-built with Tor Project — same anti-fingerprinting as Tor (resistFingerprinting, spoofed fonts/timezones, WebGL protection) but WITHOUT the Tor network (use with VPN instead). Uniform fingerprint across all installs → blending in > isolation
- Settings panel: Advanced > VPN > WireGuard > Enable multihop; relay picker with city + provider columns

Cross-cutting patterns observed:
- **3-tier security slider** (Tor) — universally admired; Brave, Mullvad all mimic
- **Per-site controls** (Brave Shields, Tor circuit-per-tab, DDG Privacy Grade) — every competitor gives per-site granularity
- **AI summarizer at top of SERP with citations** (Brave) + **AI chat anonymized server-side** (Duck.ai) — two complementary AI patterns
- **No-account / pseudonymous signup** (Mullvad, Duck.ai) — removes the biggest tracking vector
- **Multi-hop with jurisdiction separation** (Mullvad) — strengthens شبح's existing 3-hop visual story
- **Speed Dial / shortcuts layer** (Opera + DDG bangs) — power-user fast access
- **Visible privacy telemetry** (DDG Privacy Grade, Brave Shields block-counts) — gamifies privacy, builds trust

Stage Summary:

**Concrete UI/UX recommendations for شبح (what to copy from each):**
1. From Tor: keep the 3-hop circuit panel (already built) — add a **per-site "New Circuit" button** (rotate path for current site only, NOT global identity) and a **"New Identity" button** (rotate everything + clear session cache)
2. From Tor: add a **3-tier Security slider** (عادي / أكثر أمانًا / الأكثر أمانًا) that toggles: JS execution in proxy view, fonts/media loading, image rendering, WebRTC — mirror Tor's exact trade-off copy ("قد تتعطل بعض المواقع")
3. From Brave: add a **Summarizer block pinned at TOP of SERP** — concise Arabic answer with inline citation links (١، ٢، ٣) pulled from the top web_search results; one-togle to disable (toggle in settings + per-query "بدون ملخّص" link)
4. From Duck.ai: add an **anonymous AI chat tab** alongside Web/News/Images — multi-model (use z-ai chat function server-side, anonymized, no training, no account)
5. From DDG: implement **!bangs-style shortcuts** in the search bar — `!ويكي query` → Wikipedia, `!يوتيوب query` → YouTube, `!شبح proxy url` → open URL in proxy view. Start with curated 20–30 Arabic-friendly bangs
6. From DDG: surface a **Privacy Grade badge** per result (A–F) based on trackers/HTTPS — small green/amber/red pill beside each result card
7. From Opera: add a **collapsible AI sidebar** ("شبح AI") always-available on results + proxy views — drag-out-to-tab option, page-summary action ("لخّص هذه الصفحة") on proxy view using z-ai chat
8. From Opera: add a **Speed-Dial style home grid** (8–12 quick tiles: ويكيبيديا، يوتيوب، الجزيرة، جوجل، تويتر…) each opening via proxy by default
9. From Mullvad: add a **multi-hop selector** in privacy panel — user picks Entry country + Exit country from dropdowns (currently random); show jurisdiction separation visually (different colored flags)
10. From Mullvad: emphasize **no-account, no-email** model in onboarding — show a generated session ID on first visit ("هويتك: SHB-7F3K-9QZ2") that auto-rotates every 24h

**Recommended settings panel structure (شبح Settings):**
- **عام (General)**: default search action (open in proxy / open direct), language (العربية / English), theme accent (lime default), homepage speed-dial customization
- **الدائرة (Circuit)**: number of hops (3/4/5), entry/exit country pickers, auto-rotate interval (never / 10min / per-site), "New Identity" button, bridge/pluggable-transport toggle (future Tor bridge support)
- **الأمان (Security)**: 3-tier slider (عادي / أكثر أمانًا / الأقصى), JS toggle in proxy, image/media toggle, WebRTC block, HTTPS-only mode, fingerprint spoof (timezone, fonts, WebGL, User-Agent)
- **الخصوصية (Privacy)**: no-logs confirmation, cookie policy (session-only / never-store), kill-switch indicator (always-on badge), clear session button
- **البحث (Search)**: AI Summarizer toggle, AI chat model picker, !bangs enable + custom bangs editor, safe-search, region override, results per page
- **الحظر (Blocking)**: tracker/ad block toggles per category (analytics, social, ads, fingerprinters), per-site overrides list, custom blocklist import
- **حول (About)**: version, no-account manifesto, session ID, audit log of local actions only (never sent server-side)

**Recommended admin dashboard metrics (for شبح admin panel — privacy-respecting, aggregate-only):**
- Active sessions (count, no IPs)
- Searches/min, peak, 24h trend (no query text — only counts and tab/category buckets)
- Proxy fetches/min by destination TLD only (never full URLs in admin logs)
- Circuit rotation frequency + average hops-in-use
- AI summarizer usage rate (% of SERP with summarizer enabled)
- !bang hit frequency by bang-key (no per-user attribution)
- Cache hit rate (search 5min, proxy 30min) — capacity planning metric
- Top exit-node countries by request volume
- Kill-switch / blocked-tracker counts (aggregate)
- Average response latency (search, proxy, AI) — SLO dashboard
- **Design principle: admin panel sees ONLY aggregate counters and rolling-window stats — NEVER a query string, URL, or session ID. All per-user data stays in the client's local Zustand store.**

**Recommended AI-search integration pattern (شبح AI):**
- Layer 1 — **Summarizer** (Brave-style): on every web_search response, run a second server-side z-ai chat call with top-5 result snippets as context → return 2–3 sentence Arabic summary with inline citation indices [١] [٢] [٣] mapping to result-card rank. Cache 5min alongside search results. Toggle in settings + per-query dismiss.
- Layer 2 — **AI Chat tab** (Duck.ai-style): dedicated view, multi-turn, system prompt reinforces Arabic + privacy context, calls z-ai chat server-side which strips user-identifying metadata before forwarding; no chat history persisted server-side; client stores last 20 messages in Zustand only.
- Layer 3 — **Page summarizer** (Opera Aria-style): on proxy-view, floating "لخّص" action button → sends sanitized page text (already extracted by page_reader) to z-ai chat → returns Arabic bullet summary; no original URL forwarded to model context beyond domain name.
- All three layers share one z-ai backend client (`src/lib/zai.ts` already exists) — just add `summarizeSearch(query, results)` and `chatStream(messages)` helpers; expose new endpoints `/api/ai/summarize` and `/api/ai/chat`.
- Privacy contract: server only sees query + sanitized context; never correlates to session ID beyond the 5min search cache; AI providers (upstream) never see user IP (we are the proxy).

**Recommended multi-hop routing visualization (extends current privacy-panel):**
- Replace the static 3-flag row with an **animated SVG path** showing the user → Guard (entry, country A) → Middle (relay, country B) → Exit (country C) → target site, with pulsing dots traveling along the line
- Each hop node = clickable card → shows: country flag, server alias (e.g., "guard-fr-03"), jurisdiction name, latency (ms), load %
- "بدّل الدائرة لهذا الموقع" (New Circuit for this site) button — rotates Middle+Exit only, keeps Guard stable (Tor pattern)
- "هوية جديدة" (New Identity) button — rotates all hops + clears proxy cache + regenerates session ID
- Advanced view: user-pinned entry/exit countries (Mullvad-style) with "jurisdiction separation" warning if same country chosen for two hops
- Live "bytes through this circuit" counter that resets on rotation — gives tangible feel of traffic flow


---
Task ID: 3-a
Agent: general-purpose (AI integration)
Task: Build AI summarizer + chat endpoints + UI components

Work Log:
- Read worklog.md, zai.ts, search/proxy API routes, ai-store.ts, search-store.ts, settings-store.ts, result-card.tsx, logo.tsx to understand existing patterns
- Created /api/ai/summarize/route.ts: POST endpoint accepting { query, results[top-5] }, builds Arabic system prompt instructing concise 2-3 sentence summary with [١][٢] inline citations (Arabic-Indic digits), strict no-IP/session-leak rules, in-memory 5-min cache keyed by djb2 hash of query+result URLs, 60s timeout race, returns { reply, sources[] } (cited subset mapped back to result indices via regex parse of [n] tokens), 502 on error with friendly Arabic message
- Created /api/ai/chat/route.ts: POST endpoint accepting { message, history, contextUrl? }, builds system prompt per spec (with-context vs default), dedupes message-vs-history (store sends both, history includes latest user turn), 5-min timeout race, returns { reply, sources: [] }, NO persistence/cache/log of user content, error path explicitly notes "no message content logged"
- Created /components/shabah/ai-summarizer.tsx: reads useSearchStore (query, results, summary, summarySources, summaryLoading, setSummary, setSummaryLoading, startProxy) and useSettingsStore.aiSummarizer; ref-tracked fetch (one shot per query+results-set) fires when ≥2 results && summary===null; renders sleek RTL card with Ghost icon + "موجز شبح AI" header + shimmer-skeleton during load + parsed-citation superscript buttons (regex /[0-9\u0660-\u0669]+/) that call startProxy(result.url); dismissible via X (sets summary="" to suppress refetch); cited-source list footer; respects settings toggle (returns null when off)
- Created /components/shabah/ai-panel.tsx: AnimatePresence-driven slide-in aside fixed to physical-LEFT edge (380px, full height) with backdrop blur + close-on-backdrop-click; header (Ghost logo + "شبح AI" + context badge if contextUrl + clear button + close button); message list (RTL column, user msgs via justify-end → visual LEFT with primary fill, assistant msgs via justify-start → visual RIGHT with primary-tint bubble + rounded corners); framer-motion 3-dot bouncing loader during sendMessage; textarea + send button (Enter=send, Shift+Enter=newline); footer micro-copy "مجهّل — غير مستخدم في التدريب"; auto-scroll to bottom on new messages
- Removed an unused eslint-disable directive after first lint pass (ai-summarizer.tsx)
- Verified: `bun run lint` → 0 errors, 7 warnings (all pre-existing in untouched files); dev server compiles cleanly; new files only touch the 4 specified paths

Stage Summary:
- Files created (exactly the 4 specified, no other files modified):
  - src/app/api/ai/summarize/route.ts
  - src/app/api/ai/chat/route.ts
  - src/components/shabah/ai-summarizer.tsx
  - src/components/shabah/ai-panel.tsx
- Reuses `import { getZai } from "@/lib/zai"` for the shared ZAI SDK client; both endpoints use `runtime = "nodejs"`, `dynamic = "force-dynamic"`
- Privacy contract honored: summarize has in-memory 5-min cache only (no persistence); chat has ZERO persistence/cache and error path explicitly avoids logging message content; system prompts instruct the model to never reveal user/session/IP info
- All UI text RTL Arabic; uses existing theme tokens (border-border, bg-card, bg-primary, text-primary, text-primary-foreground); framer-motion already in package.json
- The two client components are ready to be wired into page.tsx/results-view.tsx by a future task (per task constraint 3-a does NOT modify those files)

---
Task ID: 4
Agent: main
Task: Rebrand to "شبح" + build sidebar, settings, admin dashboard, AI summarizer/chat, multi-hop, firewall, light/dark theme

Work Log:
- Copied user's ghost logo (navy/cyan gradient) to public/shabah-logo.png + shabah-logo-light.png
- VLM-analyzed both logo variants: ghost with magnifying glass, navy blue + cyan gradient
- Rewrote globals.css: cyan/navy primary (matching logo), full light mode, glass, glow, pulse, ghost-float, circuit-flow animations
- Updated layout.tsx: ThemeProvider (next-themes), RTL Arabic, shabah metadata
- Created stores: settings-store (persisted prefs, 7 sections incl. security level), ai-store (chat, no persistence), admin-store (aggregate counters only)
- Upgraded privacy-store: sessionId (SHB-XXXX-XXXX), 3-hop relays with role/load/latency, firewallActive, blockedAttempts, newIdentity()
- Built components/shabah/: theme-provider, theme-toggle, logo (dark/light swap), session-id-badge, privacy-grade (A-F), security-slider (Tor 3-tier), bangs.ts (15 !bangs), countries.ts, sidebar (Opera Aria style: collapsible, mobile bottom bar), settings-view (7 sections), admin-dashboard (metrics, charts, system health, TLD buckets)
- Subagent (Task 3-a) built: /api/ai/summarize (cached, citation parsing), /api/ai/chat (zero persistence), ai-summarizer component, ai-panel component (slide-in, framer-motion)
- Updated /api/search + /api/proxy to record metrics via new lib/metrics.ts
- Created /api/admin/metrics (CPU/Mem/Net sampling + aggregate counters)
- Rewrote home-screen: ghost logo + speed-dial (Opera-style 8 quick-launch tiles open via proxy) + !bangs hints + features grid + session/AI/privacy promise cards
- Updated results-view: AI summarizer block above results, privacy-grade badges per result, "لخّص بـ AI" button on each card
- Updated result-card: privacy grade badge, AI summarize button, refined layout
- Updated privacy-panel: firewall mini-status, session ID badge, dual buttons (دورة + هوية)
- Updated footer: firewall status, encryption, session ID
- Updated page.tsx: sidebar + main + AI panel + mobile bottom bar + footer in flex layout
- Fixed: logo/session-id/bangs import paths (search-engine → shabah), AiPanel→AiPanel export name, AISummarizer→AiSummarizer

Verification (agent-browser end-to-end):
- Home renders with sidebar (collapse toggle, شبح AI button, هوية جديدة, session SHB-XXXX-XXXX, theme toggle), speed-dial grid, !bangs chips, features
- Settings: 7 tabs (عام/الدائرة/الأمان/الخصوصية/البحث/الجدار الناري/حول) all working, security slider 3-tier, country pickers for entry/exit
- Admin dashboard: 4 metric cards (searches/proxied/AI/blocked), latency chart, cache hit rate, bytes saved, current circuit visualization, system health (CPU/Mem/Net), TLD distribution
- Search "ما هو Tor": AI summarizer block appears above results with clickable [١][٢] citations + sources list, results show privacy-grade badges (A/C), each card has تصفّح مجهّل + لخّص بـ AI + مباشر
- AI chat: sent "ما الفرق بين Tor و VPN" → got contextual Arabic answer referencing the browsed page (context-aware)
- Anonymous proxy: clicked تصفّح مجهّل on YouTube result → page loaded with fake exit IP (رومانيا)
- Theme toggle: dark↔light works (html class switches dark/light)
- Mobile (400x800): bottom nav bar (الرئيسية/بحث/إعدادات/AI) replaces sidebar
- bun run lint: 0 errors, 5 warnings (unused eslint-disable)

Stage Summary:
- Project rebranded from "OnionSearch" → "شبح" with user's ghost logo
- Sidebar (Opera Aria style, collapsible) + mobile bottom bar
- 7-section settings panel (general/circuit/security/privacy/search/firewall/about)
- Admin dashboard with live metrics (CPU/Mem/Net, cache hit rate, TLD distribution, latency chart)
- AI integration: summarizer above SERP + slide-in chat panel with context awareness
- Multi-hop with selectable entry/exit countries + session ID + new identity
- Firewall status visible everywhere (sidebar/footer/privacy panel/admin)
- Light + dark theme via next-themes, RTL Arabic throughout
- All competitor research recommendations implemented: Tor 3-tier slider, Opera speed-dial + Aria sidebar, DDG !bangs + privacy grade, Brave AI summarizer, Mullvad session ID + multi-hop country pickers
